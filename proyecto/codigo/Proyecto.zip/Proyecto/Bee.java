/**
 * Description
 * 
 * @author Catalina Lopez, Andres Chaves
 * @version 1
 */
public class Bee
{
    //Coordinates
    public float x;
    public float y;
    public float z;

    //Constructor method
    public Bee (float x, float y, float z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

    //Getters
    public float getX(){
        return x;
    }

    public float getY(){
        return y;
    }

    public float getZ(){
        return z;
    }
}